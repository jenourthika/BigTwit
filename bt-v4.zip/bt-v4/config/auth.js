// config/auth.js

// expose our config directly to our application using module.exports
module.exports = {


	'twitterAuth' : {
		'consumerKey' 		: 'GGVT8EFvZP2ug5nCWPk3U3dSD',
		'consumerSecret' 	: 'IhU5ojVzf3un8WVCVPSGGDaY5PywqE2yigvCwufqi3arNbnWdW',
		'callbackURL' 		: 'http://127.0.0.1:3000/auth/twitter/callback'
	},

};