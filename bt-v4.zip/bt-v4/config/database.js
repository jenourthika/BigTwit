// config/database.js
/*module.exports = {

	'url' : 'your_database_here' // looks like mongodb://<user>:<pass>@mongo.onmodulus.net:27017/Mikha4ot

};

*/